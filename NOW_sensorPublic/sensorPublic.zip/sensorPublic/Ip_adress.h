//#include "Ip_adress.h"
#ifndef IP_ADRESS_H
#define IP_ADRESS_H
#include <Arduino.h>
void Input_adress(String ip, unsigned char &num1, unsigned char &num2, unsigned char &num3, unsigned char &num4);

#endif